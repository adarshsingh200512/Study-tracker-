# Study Tracker Final
Native Java Android app. Features: Calendar, daily timeline, study sessions, subjects/topics, video completion, revision tick, last/next revision dates, reminders/notifications, notes, focus rating, analytics, visible logo.

IMPORTANT: GitHub does not execute a workflow hidden inside a ZIP. The repository must already contain the workflow at `.github/workflows/build.yml`. Once that workflow is in the repo, uploading this ZIP directly to the repo root lets the workflow extract it and build the APK.

GITHUB ZIP UPLOAD NOTE
----------------------
This archive is prepared so a GitHub Actions workflow can find the ZIP in the
repository and extract/build it automatically. GitHub itself does NOT activate
a workflow hidden inside a ZIP uploaded as a binary file. The workflow file
must be committed once under .github/workflows/ in the repository.

