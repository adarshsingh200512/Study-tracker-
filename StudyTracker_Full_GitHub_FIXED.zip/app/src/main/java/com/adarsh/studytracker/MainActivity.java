package com.adarsh.studytracker;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import java.text.SimpleDateFormat;
import java.util.*;

import androidx.activity.ComponentActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends ComponentActivity {
    SharedPreferences prefs;
    LinearLayout schedule, progress;
    final String KEY_SCHEDULE = "schedules";
    final String KEY_TOPICS = "topics";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("study_tracker", MODE_PRIVATE);
        schedule = findViewById(R.id.scheduleContainer);
        progress = findViewById(R.id.progressContainer);
        findViewById(R.id.btnAddSchedule).setOnClickListener(v -> addScheduleDialog());
        findViewById(R.id.btnManage).setOnClickListener(v -> manageDialog());
        requestNotificationPermission();
        refresh();
    }

    void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9);
    }

    void refresh() {
        schedule.removeAllViews(); progress.removeAllViews();
        String data = prefs.getString(KEY_SCHEDULE, "");
        if (data.isEmpty()) {
            TextView t = label("No reminders yet. Add your subjects and times.");
            schedule.addView(t);
        } else {
            for (String item : data.split("\\|", -1)) {
                if (item.trim().isEmpty()) continue;
                String[] p = item.split("~", -1);
                if (p.length < 3) continue;
                LinearLayout row = card();
                TextView tx = label(p[1] + "\n" + p[2]);
                tx.setTextSize(16); row.addView(tx, new LinearLayout.LayoutParams(0,-2,1));
                Button edit = smallButton("Edit");
                edit.setOnClickListener(v -> editScheduleDialog(p[0]));
                row.addView(edit);
                schedule.addView(row);
            }
        }
        String topics = prefs.getString(KEY_TOPICS, "");
        if (topics.isEmpty()) {
            progress.addView(label("No topics yet. Add a topic and its videos."));
        } else {
            for (String item : topics.split("\\|", -1)) {
                String[] p = item.split("~", -1);
                if (p.length < 4) continue;
                String[] vids = p[3].isEmpty() ? new String[0] : p[3].split(";", -1);
                int done=0; for(String x:vids) if(x.startsWith("1#")) done++;
                int pct = vids.length == 0 ? 0 : Math.round(done * 100f / vids.length);
                LinearLayout row = card();
                TextView tx = label(p[1] + " • " + p[2] + "\n" + done + "/" + vids.length + " videos • " + pct + "%");
                tx.setTextSize(15); row.addView(tx, new LinearLayout.LayoutParams(0,-2,1));
                Button open = smallButton("Open");
                open.setOnClickListener(v -> topicDialog(p[0]));
                row.addView(open); progress.addView(row);
            }
        }
    }

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL); l.setPadding(16,14,8,14);
        l.setBackgroundResource(android.R.drawable.dialog_holo_light_frame);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,8); l.setLayoutParams(lp); return l;
    }
    TextView label(String s){ TextView t=new TextView(this); t.setText(s); t.setTextColor(0xff20242c); t.setPadding(4,4,4,4); return t; }
    Button smallButton(String s){ Button b=new Button(this); b.setText(s); return b; }

    void addScheduleDialog() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(30,10,30,0);
        EditText name = new EditText(this); name.setHint("Subject (e.g. Maths)"); box.addView(name);
        TextView time = label("Choose time"); time.setPadding(4,18,4,18); box.addView(time);
        final int[] hm={18,0};
        time.setOnClickListener(v -> new TimePickerDialog(this,(d,h,m)->{hm[0]=h;hm[1]=m;time.setText(String.format(Locale.getDefault(),"Time: %02d:%02d",h,m));},18,0,true).show());
        new AlertDialog.Builder(this).setTitle("Add study reminder").setView(box).setPositiveButton("Save",(d,w)->{
            String id=UUID.randomUUID().toString(); String tm=String.format(Locale.getDefault(),"%02d:%02d",hm[0],hm[1]);
            addSchedule(id,name.getText().toString().trim(),tm); scheduleAlarm(id,name.getText().toString().trim(),hm[0],hm[1]); refresh();
        }).setNegativeButton("Cancel",null).show();
    }

    void editScheduleDialog(String id) {
        String found=findSchedule(id); if(found==null)return; String[] p=found.split("~",-1);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(30,10,30,0);
        EditText name=new EditText(this);name.setText(p[1]);box.addView(name);
        EditText tm=new EditText(this);tm.setText(p[2]);tm.setHint("HH:MM");box.addView(tm);
        new AlertDialog.Builder(this).setTitle("Edit reminder").setView(box).setPositiveButton("Save",(d,w)->{
            replaceSchedule(id,name.getText().toString().trim(),tm.getText().toString().trim()); cancelAlarm(id);
            try {String[] z=tm.getText().toString().split(":");scheduleAlarm(id,name.getText().toString(),Integer.parseInt(z[0]),Integer.parseInt(z[1]));}catch(Exception ignored){}
            refresh();
        }).setNeutralButton("Delete",(d,w)->{removeSchedule(id);cancelAlarm(id);refresh();}).setNegativeButton("Cancel",null).show();
    }

    void addSchedule(String id,String name,String time){String old=prefs.getString(KEY_SCHEDULE,"");prefs.edit().putString(KEY_SCHEDULE,old+(old.isEmpty()?"":"|")+id+"~"+name+"~"+time).apply();}
    String findSchedule(String id){for(String x:prefs.getString(KEY_SCHEDULE,"").split("\\|",-1)){if(x.startsWith(id+"~"))return x;}return null;}
    void replaceSchedule(String id,String n,String t){StringBuilder s=new StringBuilder();for(String x:prefs.getString(KEY_SCHEDULE,"").split("\\|",-1)){if(x.startsWith(id+"~"))x=id+"~"+n+"~"+t;if(!x.isEmpty())s.append((s.length()==0?"":"|")+x);}prefs.edit().putString(KEY_SCHEDULE,s.toString()).apply();}
    void removeSchedule(String id){StringBuilder s=new StringBuilder();for(String x:prefs.getString(KEY_SCHEDULE,"").split("\\|",-1)){if(!x.startsWith(id+"~")&&!x.isEmpty())s.append((s.length()==0?"":"|")+x);}prefs.edit().putString(KEY_SCHEDULE,s.toString()).apply();}

    void scheduleAlarm(String id,String subject,int h,int m){
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        Intent i=new Intent(this,ReminderReceiver.class);i.putExtra("subject",subject);i.putExtra("time",String.format(Locale.getDefault(),"%02d:%02d",h,m));
        PendingIntent pi=PendingIntent.getBroadcast(this,Math.abs(id.hashCode()),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,m);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.before(Calendar.getInstance()))c.add(Calendar.DAY_OF_YEAR,1);
        if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
        else am.set(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);
    }
    void cancelAlarm(String id){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);Intent i=new Intent(this,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,Math.abs(id.hashCode()),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pi!=null)am.cancel(pi);}

    void manageDialog(){
        new AlertDialog.Builder(this).setTitle("Manage")
            .setItems(new String[]{"Add / edit topic & videos","Edit reminders"},(d,w)->{if(w==0) addTopicDialog(); else addScheduleDialog();}).show();
    }
    void addTopicDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(30,10,30,0);
        EditText subject=new EditText(this);subject.setHint("Subject (e.g. Maths)");box.addView(subject);
        EditText topic=new EditText(this);topic.setHint("Topic (e.g. Percentage)");box.addView(topic);
        new AlertDialog.Builder(this).setTitle("New topic").setView(box).setPositiveButton("Create",(d,w)->{
            String id=UUID.randomUUID().toString();String old=prefs.getString(KEY_TOPICS,"");prefs.edit().putString(KEY_TOPICS,old+(old.isEmpty()?"":"|")+id+"~"+subject.getText()+"~"+topic.getText()+"~").apply();topicDialog(id);refresh();
        }).setNegativeButton("Cancel",null).show();
    }

    void topicDialog(String id){
        String found=findTopic(id);if(found==null)return;String[] p=found.split("~",-1);String videos=p.length>3?p[3]:"";
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(20,0,20,0);
        TextView head=label(p[1]+" — "+p[2]);head.setTextSize(19);box.addView(head);
        LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);box.addView(list);
        Runnable redraw=()->{
            list.removeAllViews();String cur=findTopic(id);if(cur==null)return;String[] q=cur.split("~",-1);String vs=q.length>3?q[3]:"";String[] arr=vs.isEmpty()?new String[0]:vs.split(";",-1);
            int done=0;for(String a:arr)if(a.startsWith("1#"))done++;
            head.setText(q[1]+" — "+q[2]+"   ("+(arr.length==0?0:Math.round(done*100f/arr.length))+"%)");
            for(int k=0;k<arr.length;k++){final int idx=k;String[] z=arr[k].split("#",2);CheckBox cb=new CheckBox(this);cb.setText(z.length>1?z[1]:arr[k]);cb.setChecked(z[0].equals("1"));cb.setOnCheckedChangeListener((v,checked)->{setVideoChecked(id,idx,checked);redraw.run();});list.addView(cb);}
        };
        redraw.run();
        new AlertDialog.Builder(this).setTitle("Video checklist").setView(box).setPositiveButton("Add video",(d,w)->addVideoDialog(id))
            .setNeutralButton("Edit names",(d,w)->editVideoNamesDialog(id)).setNegativeButton("Close",null).show();
    }
    void addVideoDialog(String id){EditText e=new EditText(this);e.setHint("Video name");new AlertDialog.Builder(this).setTitle("Add video").setView(e).setPositiveButton("Add",(d,w)->{String f=findTopic(id);String[] p=f.split("~",-1);String v=p.length>3?p[3]:"";v+=(v.isEmpty()?"":";")+"0#"+e.getText();replaceTopic(id,p[1],p[2],v);refresh();}).setNegativeButton("Cancel",null).show();}
    void editVideoNamesDialog(String id){
        String f=findTopic(id);String[] p=f.split("~",-1);String[] a=p.length>3&& !p[3].isEmpty()?p[3].split(";",-1):new String[0];
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(25,0,25,0);ArrayList<EditText> es=new ArrayList<>();
        for(String x:a){String[] z=x.split("#",2);EditText e=new EditText(this);e.setText(z.length>1?z[1]:x);es.add(e);box.addView(e);}
        new AlertDialog.Builder(this).setTitle("Edit video names").setView(box).setPositiveButton("Save",(d,w)->{StringBuilder v=new StringBuilder();for(int i=0;i<es.size();i++){if(i>0)v.append(";");v.append(a[i].startsWith("1#")?"1#":"0#").append(es.get(i).getText());}replaceTopic(id,p[1],p[2],v.toString());refresh();}).setNegativeButton("Cancel",null).show();
    }
    void setVideoChecked(String id,int idx,boolean checked){String f=findTopic(id);String[] p=f.split("~",-1);String[] a=p.length>3&&!p[3].isEmpty()?p[3].split(";",-1):new String[0];if(idx<0||idx>=a.length)return;String[] z=a[idx].split("#",2);a[idx]=(checked?"1#":"0#")+(z.length>1?z[1]:"");replaceTopic(id,p[1],p[2],String.join(";",a));refresh();}
    String findTopic(String id){for(String x:prefs.getString(KEY_TOPICS,"").split("\\|",-1))if(x.startsWith(id+"~"))return x;return null;}
    void replaceTopic(String id,String s,String t,String v){StringBuilder out=new StringBuilder();for(String x:prefs.getString(KEY_TOPICS,"").split("\\|",-1)){if(x.startsWith(id+"~"))x=id+"~"+s+"~"+t+"~"+v;if(!x.isEmpty())out.append((out.length()==0?"":"|")+x);}prefs.edit().putString(KEY_TOPICS,out.toString()).apply();}
}
