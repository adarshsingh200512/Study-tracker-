# Study Tracker

GitHub-ready Android project for the Study Tracker app.

## Included
- Dark/neon Study Tracker UI
- Calendar and date-based daily reports
- Subject -> Topic/Chapter -> unlimited Videos
- Editable video names
- Video completion checkboxes
- Automatic watched date for completed videos
- Topic video counts and progress
- Topic revision checklist with completion dates
- Study timer with focus score
- Subject/topic study reminders and Android notifications
- Tasks
- Notes
- Offline SQLite storage
- Weekly analytics
- GitHub Actions APK build

## GitHub Actions
The workflow is at `.github/workflows/build-apk.yml` and builds a debug APK as the `Study-Tracker-APK` artifact.

**Important GitHub limitation:** GitHub does not execute a workflow file that is still inside an uploaded ZIP archive. For Actions to run, the repository must contain the project files and `.github/workflows/build-apk.yml` at repository root. If you upload the ZIP as a single file through GitHub's web uploader, it remains a ZIP file and the workflow cannot start from inside it. Extract the archive into the repository root, or use a Git client/API to upload the extracted files.
