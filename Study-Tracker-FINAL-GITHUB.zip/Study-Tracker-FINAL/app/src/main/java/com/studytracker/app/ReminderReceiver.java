package com.studytracker.app;
import android.app.*; import android.content.*; import androidx.core.app.NotificationCompat;
public class ReminderReceiver extends BroadcastReceiver {
 public void onReceive(Context c, Intent i) {
  String s=i.getStringExtra("subject"), t=i.getStringExtra("topic"), d=i.getStringExtra("duration");
  String ch="study_reminders"; NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(android.os.Build.VERSION.SDK_INT>=26)n.createNotificationChannel(new NotificationChannel(ch,"Study Reminders",NotificationManager.IMPORTANCE_HIGH));
  Intent open=new Intent(c,MainActivity.class); PendingIntent p=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  n.notify((int)(System.currentTimeMillis()%100000),new NotificationCompat.Builder(c,ch).setSmallIcon(android.R.drawable.ic_popup_reminder)
   .setContentTitle("Study Reminder • "+s).setContentText(t+" • "+d).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(p).build());
 }
}
