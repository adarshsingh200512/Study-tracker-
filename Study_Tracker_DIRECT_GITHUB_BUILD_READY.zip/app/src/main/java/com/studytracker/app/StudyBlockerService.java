package com.studytracker.app;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

public class StudyBlockerService extends AccessibilityService {
    private static final String PREFS = "app_blocker";
    private static final String KEY = "blocked";
    private long lastBlock = 0;
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if ("com.studytracker.app".equals(pkg)) return;
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean("enabled", false)) return;
        Set<String> blocked = p.getStringSet(KEY, new HashSet<String>());
        if (blocked.contains(pkg) && System.currentTimeMillis()-lastBlock>700) {
            lastBlock=System.currentTimeMillis();
            performGlobalAction(GLOBAL_ACTION_HOME);
        }
    }
    @Override public void onInterrupt() {}
}
