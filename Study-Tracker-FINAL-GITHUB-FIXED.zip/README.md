# Study Tracker — Final GitHub Package

Android study tracker with a dark neon app UI and a separate light Calendar UI inspired by the supplied calendar reference.

## Included
- Study Tracker app name
- Subjects → Topics/Chapters
- Unlimited videos per topic/chapter
- Editable video names
- Per-video completion checkbox
- Watched date saved for each completed video
- Topic summary: total videos and completed videos
- Topic Revision list with completion and revision date
- Custom study timer (1 minute–24 hours)
- Daily schedule, reminders, tasks, notes and analytics
- Offline SQLite storage
- GitHub Actions APK build

## GitHub ZIP workflow
The repository workflow can build either:
1. an Android project already extracted at the repository root, or
2. a ZIP uploaded to the repository (the workflow extracts the ZIP automatically).

If uploading only the ZIP, the repository must already contain `.github/workflows/build-apk.yml` so GitHub Actions can run. After committing the ZIP, open **Actions → Build Study Tracker APK**.

Successful runs publish **Study-Tracker-APK** as an artifact containing `app-debug.apk`.
