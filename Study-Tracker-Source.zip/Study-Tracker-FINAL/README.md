# Study Tracker

A mobile-first Android study planner and tracker.

## Included
- Dark/neon Study Tracker dashboard
- Home, Syllabus, Timer, Analytics and Tasks navigation
- Monthly Calendar with date selection
- Daily Report: subject, topic, time, duration and focus score
- Custom study timer (1 minute to 24 hours)
- Study reminders with Android notifications
- Daily/repeating reminders
- Subjects and priority management
- Offline SQLite storage
- Notes
- Weekly analytics and progress

## GitHub Actions
The repository contains `.github/workflows/build-apk.yml`. Push to `main` or run the workflow manually from the Actions tab. The generated debug APK is uploaded as the `Study-Tracker-APK` artifact.

## App name
The Android app name is **Study Tracker**.
