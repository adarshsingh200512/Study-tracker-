# Study Tracker — Final GitHub Ready Android Project

A mobile-first Android study planner/tracker designed around the requested white calendar-style UI and the supplied Study Tracker logo concept.

## Main features
- Monthly Calendar Overview with month navigation and study markers.
- Daily Details & Timeline inside the same Calendar screen.
- Events & Reminders inside the same Calendar screen plus Android alarm notifications.
- Monthly Summary & Analytics inside the same Calendar screen.
- Subjects → Topics/Chapters → unlimited Videos/Lectures → Revision.
- Add as many videos as needed for one topic; each video has an editable name, completion checkbox and watched date.
- Topic card shows total videos, completed videos and percentage.
- Topic Revision section with multiple revision entries and dates.
- Home dashboard with daily target, today's study time, schedule and subject progress.
- Custom daily target and user name.
- Study timer with custom duration and quick 15/25/45/60 minute buttons.
- Completed timer session can be saved with subject, topic and focus rating.
- Tasks list with completion tracking.
- Offline notes with photo picker entry point.
- Smart Study Coach suggestion.
- Weekly/monthly analytics and subject-wise progress.
- Local SQLite storage; no internet/backend required for core tracking.
- Android notification permission and exact/inexact reminder scheduling.

## GitHub Actions
The workflow uses Java 17, Android SDK 35 and Gradle 8.9. It builds `:app:assembleDebug`, verifies the APK, and uploads `Study-Tracker-APK` as an artifact. No Gradle wrapper is required.

## GitHub phone upload
Extract this ZIP first, then upload the **contents** of the extracted folder to the repository root so `.github/workflows/build-apk.yml`, `app/`, `build.gradle`, `settings.gradle`, and `gradle.properties` are visible at the root.
