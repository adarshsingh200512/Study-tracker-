const CACHE="study-tracker-v1";const ASSETS=["./","./index.html","./pwa-manifest.json","./service-worker.js"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting())));
self.addEventListener("activate",e=>e.waitUntil(self.clients.claim()));
self.addEventListener("fetch",e=>{if(e.request.method!=="GET")return;e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request).then(res=>{let c=res.clone();caches.open(CACHE).then(k=>k.put(e.request,c));return res}).catch(()=>caches.match("./index.html"))))});