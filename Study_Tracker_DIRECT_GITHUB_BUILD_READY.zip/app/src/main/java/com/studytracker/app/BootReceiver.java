package com.studytracker.app;
import android.content.*;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){ Prefs.schedule(c); TaskPrefs.scheduleAll(c); StudyReminderPrefs.scheduleAll(c); } }
