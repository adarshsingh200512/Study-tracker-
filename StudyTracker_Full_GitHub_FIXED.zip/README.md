# Study Tracker — GitHub-ready Android project

This is a complete Android project. Upload the **contents of this ZIP** to the root of a GitHub repository
(or extract it first and upload all files). The included GitHub Actions workflow automatically builds an
installable APK.

## Features
- Editable subject study reminders with time
- Daily study schedule on the home screen
- Add/edit/delete reminders
- Add subjects and topics
- Add video lessons under each topic
- Tick videos as watched
- Automatic topic completion percentage
- Edit video names
- Local/offline data storage
- Android study-time notification reminders
- GitHub Actions workflow that builds and uploads `app-release.apk`

## GitHub steps
1. Create/open your repository.
2. Upload **all files and folders inside this ZIP** to the repository root.
3. Commit to the `main` branch.
4. Open **Actions** → **Build Study Tracker APK**.
5. Wait for the green build.
6. Open the successful run and download **Study-Tracker-release** from Artifacts.
7. Extract the artifact and install `app-release.apk`.

The release build is signed with the standard Android debug signing key so it can be installed directly.
For a Play Store release, a private production keystore should be configured later.

## Important
This version intentionally avoids the exact-alarm permission. Android may deliver reminders with a small delay
depending on battery/background restrictions. Notification permission is requested on Android 13+.


## ZIP upload mode
If you want to keep the Android project inside a ZIP, upload this ZIP as
`StudyTracker_Full_GitHub.zip` to the repository root and keep
`.github/workflows/build.yml` in the repository root. The workflow extracts
the ZIP and builds the release APK automatically.
