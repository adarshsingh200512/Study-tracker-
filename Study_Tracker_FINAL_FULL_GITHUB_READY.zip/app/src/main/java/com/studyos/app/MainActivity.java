package com.studyos.app;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.*;
import java.io.*;

public class MainActivity extends Activity {
    WebView web; static final int REQ_NOTIF=100; static final int REQ_PICK=200; static final int REQ_IMAGE=300; ValueCallback<Uri[]> imageCallback;
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        ReminderReceiver.createChannel(this);
        web=new WebView(this); web.setBackgroundColor(android.graphics.Color.rgb(6,10,18));
        WebSettings ws=web.getSettings(); ws.setJavaScriptEnabled(true); ws.setDomStorageEnabled(true); ws.setAllowFileAccess(true); ws.setAllowContentAccess(true); ws.setDatabaseEnabled(true);
        web.setWebViewClient(new WebViewClient()); web.setWebChromeClient(new WebChromeClient(){ @Override public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params){ imageCallback=cb; Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true); MainActivity.this.startActivityForResult(i,REQ_IMAGE); return true; }}); web.addJavascriptInterface(new AndroidBridge(this,web),"Android");
        web.loadUrl("file:///android_asset/index.html"); setContentView(web);
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIF);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){ super.onActivityResult(requestCode,resultCode,data); if(requestCode==REQ_IMAGE){if(imageCallback==null)return;if(resultCode!=RESULT_OK||data==null){imageCallback.onReceiveValue(null);imageCallback=null;return;}java.util.ArrayList<Uri> uris=new java.util.ArrayList<>();if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)uris.add(data.getClipData().getItemAt(i).getUri());}else if(data.getData()!=null)uris.add(data.getData());imageCallback.onReceiveValue(uris.toArray(new Uri[0]));imageCallback=null;} else if(requestCode==REQ_PICK&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){try{InputStream in=getContentResolver().openInputStream(data.getData());ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);in.close();String b64=Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP);web.evaluateJavascript("window.importBackupBase64('"+b64+"')",null);}catch(Exception e){web.evaluateJavascript("toast('Could not read backup file')",null);}}}
    @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
class AndroidBridge {
    final MainActivity c; final WebView w; AndroidBridge(MainActivity c,WebView w){this.c=c;this.w=w;}
    @JavascriptInterface public void requestNotifications(){if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)c.requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},100);ReminderReceiver.createChannel(c);}
    @JavascriptInterface public void scheduleDaily(String morning,String night,String goalCheck){Prefs.save(c,morning,night,goalCheck); c.getSharedPreferences("reminders",0).edit().putString("morningEnabled",String.valueOf(morning!=null&&!morning.isEmpty())).putString("nightEnabled",String.valueOf(night!=null&&!night.isEmpty())).putString("goalEnabled",String.valueOf(goalCheck!=null&&!goalCheck.isEmpty())).apply(); Prefs.schedule(c);}
    @JavascriptInterface public void timerDone(String title){ReminderReceiver.notifyNow(c,"Study Timer Complete",title+" is complete. Great work! 🎉");}
    @JavascriptInterface public void scheduleStudyReminder(String key,String iso,String title,String text){ReminderReceiver.scheduleStudy(c,key,iso,title,text);}
    @JavascriptInterface public void cancelStudyReminder(String key){ReminderReceiver.cancelStudy(c,key);}
    @JavascriptInterface public String getInstalledApps(){try{org.json.JSONArray a=new org.json.JSONArray();java.util.List<android.content.pm.ApplicationInfo> apps=c.getPackageManager().getInstalledApplications(0);java.util.Collections.sort(apps,new java.util.Comparator<android.content.pm.ApplicationInfo>(){public int compare(android.content.pm.ApplicationInfo x,android.content.pm.ApplicationInfo y){return c.getPackageManager().getApplicationLabel(x).toString().compareToIgnoreCase(c.getPackageManager().getApplicationLabel(y).toString());}});for(android.content.pm.ApplicationInfo ai:apps){if(ai.packageName.equals(c.getPackageName()))continue;org.json.JSONObject o=new org.json.JSONObject();o.put("package",ai.packageName);o.put("name",c.getPackageManager().getApplicationLabel(ai).toString());a.put(o);}return a.toString();}catch(Exception e){return "[]";}}
    @JavascriptInterface public String getBlockedApps(){try{java.util.Set<String> s=c.getSharedPreferences("app_blocker",0).getStringSet("blocked",new java.util.HashSet<String>());org.json.JSONArray a=new org.json.JSONArray();for(String x:s)a.put(x);return a.toString();}catch(Exception e){return "[]";}}
    @JavascriptInterface public void saveBlockedApps(String json,boolean enabled){try{org.json.JSONArray a=new org.json.JSONArray(json);java.util.HashSet<String> set=new java.util.HashSet<>();for(int i=0;i<a.length();i++)set.add(a.getString(i));c.getSharedPreferences("app_blocker",0).edit().putStringSet("blocked",set).putBoolean("enabled",enabled).apply();}catch(Exception ignored){}}
    @JavascriptInterface public void openAccessibilitySettings(){try{c.startActivity(new android.content.Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS));}catch(Exception ignored){}} @JavascriptInterface public void scheduleTaskReminder(String key,String iso,String title,String text){ReminderReceiver.scheduleAt(c,key,iso,title,text);}@JavascriptInterface public void cancelTaskReminder(String key){ReminderReceiver.cancelTask(c,key);}
    @JavascriptInterface public void saveBackup(String filename,String base64){try{byte[] data=Base64.decode(base64,Base64.DEFAULT);if(Build.VERSION.SDK_INT>=29){android.content.ContentValues v=new android.content.ContentValues();v.put(android.provider.MediaStore.Downloads.DISPLAY_NAME,filename);v.put(android.provider.MediaStore.Downloads.MIME_TYPE,"application/json");v.put(android.provider.MediaStore.Downloads.IS_PENDING,1);Uri uri=c.getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);OutputStream os=c.getContentResolver().openOutputStream(uri);os.write(data);os.close();v.clear();v.put(android.provider.MediaStore.Downloads.IS_PENDING,0);c.getContentResolver().update(uri,v,null,null);}else{File d=android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS);d.mkdirs();FileOutputStream os=new FileOutputStream(new File(d,filename));os.write(data);os.close();}}catch(Exception e){}}
    @JavascriptInterface public void pickBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");c.startActivityForResult(i,MainActivity.REQ_PICK);}
}
