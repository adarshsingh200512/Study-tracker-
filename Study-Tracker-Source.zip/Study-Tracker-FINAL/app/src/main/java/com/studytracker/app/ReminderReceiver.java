package com.studytracker.app;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    public void onReceive(Context c, Intent i){
        String subject=i.getStringExtra("subject"); String topic=i.getStringExtra("topic"); int duration=i.getIntExtra("duration",60);
        String channel="study_tracker_reminders"; NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(channel,"Study Reminders",NotificationManager.IMPORTANCE_HIGH));
        Intent open=new Intent(c,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,channel):new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("Study Reminder • "+subject).setContentText(topic+" • "+duration+" min").setAutoCancel(true).setContentIntent(pi).setPriority(Notification.PRIORITY_HIGH);
        nm.notify((int)(System.currentTimeMillis()%100000),b.build());
    }
}
