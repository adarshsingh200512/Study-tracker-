package com.studytracker.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class AppDb extends SQLiteOpenHelper {
    public AppDb(Context c){ super(c,"study_tracker.db",null,1); }
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE subjects(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,color TEXT NOT NULL,priority TEXT NOT NULL DEFAULT 'Medium')");
        db.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,subject TEXT,topic TEXT,date TEXT,time TEXT,duration INTEGER,focus INTEGER)");
        db.execSQL("CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT,subject TEXT,topic TEXT,date TEXT,time TEXT,duration INTEGER,daily INTEGER,alarmId INTEGER)");
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,date TEXT,time TEXT,done INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,body TEXT,date TEXT)");
        seed(db);
    }
    void seed(SQLiteDatabase db){
        String[] a={"Mathematics","Physics","Chemistry","Business Studies","English"};
        String[] c={"#8B5CF6","#22A7F0","#2DD4BF","#F59E0B","#EC4899"};
        for(int i=0;i<a.length;i++){ContentValues v=new ContentValues();v.put("name",a[i]);v.put("color",c[i]);v.put("priority",i==0?"High":"Medium");db.insert("subjects",null,v);}
    }
    public void onUpgrade(SQLiteDatabase db,int oldV,int newV){db.execSQL("DROP TABLE IF EXISTS subjects");db.execSQL("DROP TABLE IF EXISTS sessions");db.execSQL("DROP TABLE IF EXISTS reminders");db.execSQL("DROP TABLE IF EXISTS tasks");db.execSQL("DROP TABLE IF EXISTS notes");onCreate(db);}
    public ArrayList<String> subjects(){ArrayList<String> r=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT name FROM subjects ORDER BY id",null);while(c.moveToNext())r.add(c.getString(0));c.close();return r;}
    public int totalMinutes(String date){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(duration),0) FROM sessions WHERE date=?",new String[]{date});int n=c.moveToFirst()?c.getInt(0):0;c.close();return n;}
    public int sessionCount(String date){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM sessions WHERE date=?",new String[]{date});int n=c.moveToFirst()?c.getInt(0):0;c.close();return n;}
    public int focusTotal(String date){Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(focus),0) FROM sessions WHERE date=?",new String[]{date});int n=c.moveToFirst()?c.getInt(0):0;c.close();return n;}
    public Cursor sessions(String date){return getReadableDatabase().rawQuery("SELECT subject,topic,time,duration,focus FROM sessions WHERE date=? ORDER BY time",new String[]{date});}
    public void addSession(String subject,String topic,String date,String time,int duration,int focus){ContentValues v=new ContentValues();v.put("subject",subject);v.put("topic",topic);v.put("date",date);v.put("time",time);v.put("duration",duration);v.put("focus",focus);getWritableDatabase().insert("sessions",null,v);}
    public long addReminder(String subject,String topic,String date,String time,int duration,boolean daily,int alarmId){ContentValues v=new ContentValues();v.put("subject",subject);v.put("topic",topic);v.put("date",date);v.put("time",time);v.put("duration",duration);v.put("daily",daily?1:0);v.put("alarmId",alarmId);return getWritableDatabase().insert("reminders",null,v);}
    public Cursor reminders(){return getReadableDatabase().rawQuery("SELECT id,subject,topic,date,time,duration,daily,alarmId FROM reminders ORDER BY date,time",null);}
    public void deleteReminder(long id){getWritableDatabase().delete("reminders","id=?",new String[]{String.valueOf(id)});}
    public void addSubject(String name,String color,String priority){ContentValues v=new ContentValues();v.put("name",name);v.put("color",color);v.put("priority",priority);getWritableDatabase().insert("subjects",null,v);}
    public Cursor subjectRows(){return getReadableDatabase().rawQuery("SELECT id,name,color,priority FROM subjects ORDER BY id",null);}
    public void addTask(String title,String date,String time){ContentValues v=new ContentValues();v.put("title",title);v.put("date",date);v.put("time",time);getWritableDatabase().insert("tasks",null,v);}
    public Cursor tasks(String date){return getReadableDatabase().rawQuery("SELECT id,title,time,done FROM tasks WHERE date=? ORDER BY time",new String[]{date});}
    public void toggleTask(long id,int done){ContentValues v=new ContentValues();v.put("done",done);getWritableDatabase().update("tasks",v,"id=?",new String[]{String.valueOf(id)});}
    public void addNote(String title,String body,String date){ContentValues v=new ContentValues();v.put("title",title);v.put("body",body);v.put("date",date);getWritableDatabase().insert("notes",null,v);}
    public Cursor notes(){return getReadableDatabase().rawQuery("SELECT title,body,date FROM notes ORDER BY id DESC",null);}
    public int weekMinutes(){Calendar c=Calendar.getInstance();c.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);int n=0;for(int i=0;i<7;i++){n+=totalMinutes(f.format(c.getTime()));c.add(Calendar.DATE,1);}return n;}
}
