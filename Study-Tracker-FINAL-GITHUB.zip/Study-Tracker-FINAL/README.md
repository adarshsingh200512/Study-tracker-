# Study Tracker
Working core Android project for GitHub Actions.

Includes:
- Study Tracker app name
- Subject/topic reminder at exact time
- Android notification
- Calendar and date Daily Report
- Subject, topic, time, duration and focus logging
- Study timer
- Weekly report
- Local/offline storage

Upload the ZIP contents to a GitHub repository and run Actions > Build Study Tracker APK.
