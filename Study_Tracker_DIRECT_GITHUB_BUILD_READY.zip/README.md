# Study Tracker — Android App

A local/offline-first study planner and tracker designed around the requested Study Tracker UI and calendar/report workflow. This build uses a fresh application ID (`com.studytracker.app`) so it does not conflict with older Study Tracker APKs.

## Included
- Dashboard with daily goal, streak, focus score and smart next topic
- Subjects → Chapters → Topics → Sub-topics structure
- Editable video/class lists per topic with watched checkboxes and video completion %
- Custom study timer with actual duration + focus score logging
- Subject/topic/date reminders with Android notifications
- Monthly calendar with study-history indicators and tap-to-open Daily Study Report
- Daily reports: goal, total study, subject/topic time, study times, focus and reminders
- Weekly analytics and study breakdown
- Revision due tracking
- Tasks with timers and reminders
- Notes with photos
- Global search
- XP and streak gamification
- Export/import backup
- Dark/light mode
- Offline local storage
- GitHub Actions workflow that builds a debug APK

## Build
Upload this repository/ZIP to GitHub, then open **Actions → Build Study Tracker APK → Run workflow**. The generated APK is available under the workflow Artifacts.

## Important Android limitation
The included Focus Mode is an in-app distraction-free mode. True Android-wide blocking of other apps requires the user to explicitly grant Android Accessibility access and a dedicated blocking service; that permission is intentionally not silently enabled.

## Installability note
The Android Accessibility Service has been removed from this install-safe build because it can trigger Google Play Protect sensitive-data warnings when a locally sideloaded APK is installed. In-app Focus Mode remains available; OS-level app blocking is not enabled in this build.
