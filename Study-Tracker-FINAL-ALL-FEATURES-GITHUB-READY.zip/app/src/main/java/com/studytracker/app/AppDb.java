package com.studytracker.app;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class AppDb extends SQLiteOpenHelper {
    public AppDb(Context c){ super(c,"study_tracker.db",null,3); }
    @Override public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE subjects(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,color TEXT NOT NULL,priority TEXT NOT NULL DEFAULT 'Medium',target_hours REAL DEFAULT 30)");
        db.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,subject TEXT,topic TEXT,date TEXT,time TEXT,duration INTEGER,focus INTEGER)");
        db.execSQL("CREATE TABLE reminders(id INTEGER PRIMARY KEY AUTOINCREMENT,subject TEXT,topic TEXT,date TEXT,time TEXT,duration INTEGER,daily INTEGER,alarmId INTEGER)");
        db.execSQL("CREATE TABLE tasks(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,date TEXT,time TEXT,done INTEGER DEFAULT 0)");
        db.execSQL("CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT,title TEXT,body TEXT,date TEXT,photo_uri TEXT DEFAULT '')");
        db.execSQL("CREATE TABLE topics(id INTEGER PRIMARY KEY AUTOINCREMENT,subject_id INTEGER NOT NULL,name TEXT NOT NULL,priority TEXT DEFAULT 'Medium',status TEXT DEFAULT 'Not Started',estimated_hours REAL DEFAULT 1,target_date TEXT DEFAULT '')");
        db.execSQL("CREATE TABLE videos(id INTEGER PRIMARY KEY AUTOINCREMENT,topic_id INTEGER NOT NULL,name TEXT NOT NULL,completed INTEGER DEFAULT 0,watched_date TEXT DEFAULT '')");
        db.execSQL("CREATE TABLE revisions(id INTEGER PRIMARY KEY AUTOINCREMENT,topic_id INTEGER NOT NULL,revision_no INTEGER NOT NULL,revision_date TEXT,completed INTEGER DEFAULT 0)");
        seed(db);
    }
    void seed(SQLiteDatabase db){
        String[] a={"Mathematics","Physics","Chemistry","Business Studies","English"};
        String[] c={"#0B8F78","#2878D8","#F08A24","#7652C7","#D84E8B"};
        for(int i=0;i<a.length;i++){ContentValues v=new ContentValues();v.put("name",a[i]);v.put("color",c[i]);v.put("priority",i==0?"High":"Medium");v.put("target_hours",i==0?50:30);db.insert("subjects",null,v);}
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV){
        if(oldV<2){
            db.execSQL("CREATE TABLE IF NOT EXISTS topics(id INTEGER PRIMARY KEY AUTOINCREMENT,subject_id INTEGER NOT NULL,name TEXT NOT NULL,priority TEXT DEFAULT 'Medium',status TEXT DEFAULT 'Not Started')");
            db.execSQL("CREATE TABLE IF NOT EXISTS videos(id INTEGER PRIMARY KEY AUTOINCREMENT,topic_id INTEGER NOT NULL,name TEXT NOT NULL,completed INTEGER DEFAULT 0,watched_date TEXT DEFAULT '')");
            db.execSQL("CREATE TABLE IF NOT EXISTS revisions(id INTEGER PRIMARY KEY AUTOINCREMENT,topic_id INTEGER NOT NULL,revision_no INTEGER NOT NULL,revision_date TEXT,completed INTEGER DEFAULT 0)");
        }
        if(oldV<3){
            try{db.execSQL("ALTER TABLE subjects ADD COLUMN target_hours REAL DEFAULT 30");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE topics ADD COLUMN estimated_hours REAL DEFAULT 1");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE topics ADD COLUMN target_date TEXT DEFAULT ''");}catch(Exception ignored){}
            try{db.execSQL("ALTER TABLE notes ADD COLUMN photo_uri TEXT DEFAULT ''");}catch(Exception ignored){}
        }
    }
    public ArrayList<String> subjects(){ArrayList<String> r=new ArrayList<>();Cursor c=getReadableDatabase().rawQuery("SELECT name FROM subjects ORDER BY id",null);while(c.moveToNext())r.add(c.getString(0));c.close();return r;}
    public Cursor subjectRows(){return getReadableDatabase().rawQuery("SELECT id,name,color,priority,target_hours FROM subjects ORDER BY id",null);}
    public long subjectId(String name){Cursor c=getReadableDatabase().rawQuery("SELECT id FROM subjects WHERE name=? LIMIT 1",new String[]{name});long id=c.moveToFirst()?c.getLong(0):-1;c.close();return id;}
    public void addSubject(String name,String color,String priority,double target){ContentValues v=new ContentValues();v.put("name",name);v.put("color",color);v.put("priority",priority);v.put("target_hours",target);getWritableDatabase().insert("subjects",null,v);}
    public void updateSubject(long id,String name,String priority,double target){ContentValues v=new ContentValues();v.put("name",name);v.put("priority",priority);v.put("target_hours",target);getWritableDatabase().update("subjects",v,"id=?",new String[]{String.valueOf(id)});}
    public int totalMinutes(String date){return scalar("SELECT COALESCE(SUM(duration),0) FROM sessions WHERE date=?",new String[]{date});}
    public int sessionCount(String date){return scalar("SELECT COUNT(*) FROM sessions WHERE date=?",new String[]{date});}
    public int focusTotal(String date){return scalar("SELECT COALESCE(SUM(focus),0) FROM sessions WHERE date=?",new String[]{date});}
    int scalar(String q,String[] args){Cursor c=getReadableDatabase().rawQuery(q,args);int n=c.moveToFirst()?c.getInt(0):0;c.close();return n;}
    public Cursor sessions(String date){return getReadableDatabase().rawQuery("SELECT subject,topic,time,duration,focus FROM sessions WHERE date=? ORDER BY time",new String[]{date});}
    public void addSession(String subject,String topic,String date,String time,int duration,int focus){ContentValues v=new ContentValues();v.put("subject",subject);v.put("topic",topic);v.put("date",date);v.put("time",time);v.put("duration",duration);v.put("focus",focus);getWritableDatabase().insert("sessions",null,v);}
    public long addReminder(String subject,String topic,String date,String time,int duration,boolean daily,int alarmId){ContentValues v=new ContentValues();v.put("subject",subject);v.put("topic",topic);v.put("date",date);v.put("time",time);v.put("duration",duration);v.put("daily",daily?1:0);v.put("alarmId",alarmId);return getWritableDatabase().insert("reminders",null,v);}
    public Cursor reminders(){return getReadableDatabase().rawQuery("SELECT id,subject,topic,date,time,duration,daily,alarmId FROM reminders ORDER BY date,time",null);}
    public void deleteReminder(long id){getWritableDatabase().delete("reminders","id=?",new String[]{String.valueOf(id)});}
    public void addTask(String title,String date,String time){ContentValues v=new ContentValues();v.put("title",title);v.put("date",date);v.put("time",time);getWritableDatabase().insert("tasks",null,v);}
    public Cursor tasks(String date){return getReadableDatabase().rawQuery("SELECT id,title,time,done FROM tasks WHERE date=? ORDER BY time",new String[]{date});}
    public void toggleTask(long id,int done){ContentValues v=new ContentValues();v.put("done",done);getWritableDatabase().update("tasks",v,"id=?",new String[]{String.valueOf(id)});}
    public long addNote(String title,String body,String date,String photo){ContentValues v=new ContentValues();v.put("title",title);v.put("body",body);v.put("date",date);v.put("photo_uri",photo);return getWritableDatabase().insert("notes",null,v);}
    public Cursor notes(){return getReadableDatabase().rawQuery("SELECT title,body,date,photo_uri FROM notes ORDER BY id DESC",null);}
    public long addTopic(long sid,String name,double est,String priority,String status,String targetDate){ContentValues v=new ContentValues();v.put("subject_id",sid);v.put("name",name);v.put("estimated_hours",est);v.put("priority",priority);v.put("status",status);v.put("target_date",targetDate);return getWritableDatabase().insert("topics",null,v);}
    public Cursor topics(long sid){return getReadableDatabase().rawQuery("SELECT id,name,status,estimated_hours,priority,target_date FROM topics WHERE subject_id=? ORDER BY id",new String[]{String.valueOf(sid)});}
    public void updateTopic(long id,String name,String status,String priority,double est,String date){ContentValues v=new ContentValues();v.put("name",name);v.put("status",status);v.put("priority",priority);v.put("estimated_hours",est);v.put("target_date",date);getWritableDatabase().update("topics",v,"id=?",new String[]{String.valueOf(id)});}
    public long addVideo(long topicId,String name){ContentValues v=new ContentValues();v.put("topic_id",topicId);v.put("name",name);return getWritableDatabase().insert("videos",null,v);}
    public Cursor videos(long topicId){return getReadableDatabase().rawQuery("SELECT id,name,completed,COALESCE(watched_date,'') FROM videos WHERE topic_id=? ORDER BY id",new String[]{String.valueOf(topicId)});}
    public void renameVideo(long id,String name){ContentValues v=new ContentValues();v.put("name",name);getWritableDatabase().update("videos",v,"id=?",new String[]{String.valueOf(id)});}
    public void completeVideo(long id,boolean done,String date){ContentValues v=new ContentValues();v.put("completed",done?1:0);v.put("watched_date",done?date:"");getWritableDatabase().update("videos",v,"id=?",new String[]{String.valueOf(id)});}
    public int videoCount(long tid){return scalar("SELECT COUNT(*) FROM videos WHERE topic_id=?",new String[]{String.valueOf(tid)});}
    public int completedVideoCount(long tid){return scalar("SELECT COUNT(*) FROM videos WHERE topic_id=? AND completed=1",new String[]{String.valueOf(tid)});}
    public long addRevision(long tid,int no,String date){ContentValues v=new ContentValues();v.put("topic_id",tid);v.put("revision_no",no);v.put("revision_date",date);return getWritableDatabase().insert("revisions",null,v);}
    public Cursor revisions(long tid){return getReadableDatabase().rawQuery("SELECT id,revision_no,revision_date,completed FROM revisions WHERE topic_id=? ORDER BY revision_no",new String[]{String.valueOf(tid)});}
    public void completeRevision(long id,boolean done){ContentValues v=new ContentValues();v.put("completed",done?1:0);getWritableDatabase().update("revisions",v,"id=?",new String[]{String.valueOf(id)});}
    public int weekMinutes(){Calendar c=Calendar.getInstance();c.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);int n=0;for(int i=0;i<7;i++){n+=totalMinutes(f.format(c.getTime()));c.add(Calendar.DATE,1);}return n;}
    public int monthMinutes(int year,int month){Calendar c=Calendar.getInstance();c.set(year,month,1);int days=c.getActualMaximum(Calendar.DAY_OF_MONTH);SimpleDateFormat f=new SimpleDateFormat("yyyy-MM-dd",Locale.US);int n=0;for(int i=1;i<=days;i++){c.set(Calendar.DAY_OF_MONTH,i);n+=totalMinutes(f.format(c.getTime()));}return n;}
    public int allTopics(){return scalar("SELECT COUNT(*) FROM topics",null);}
    public int completedTopics(){return scalar("SELECT COUNT(*) FROM topics WHERE status='Completed'",null);}
}
