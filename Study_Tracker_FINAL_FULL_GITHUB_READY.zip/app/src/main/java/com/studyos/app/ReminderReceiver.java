package com.studyos.app;

import java.text.SimpleDateFormat;
import android.app.*;
import android.content.*;
import android.os.Build;
import java.util.*;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CH = "study_tracker_reminders";

    public static void createChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(
                    CH, "Study Tracker Reminders", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Study Tracker study reminders and timer alerts");
            nm.createNotificationChannel(ch);
        }
    }

    @Override
    public void onReceive(Context c, Intent i) {
        createChannel(c);
        notifyNow(c, i.getStringExtra("title"), i.getStringExtra("text"));
        int rid = i.getIntExtra("id", 0);
        if (rid >= 1 && rid <= 3) {
            Prefs.schedule(c);
        } else if (rid >= 50000 && rid < 60000) {
            // One-time subject/topic reminder. It is intentionally not re-scheduled.
        } else if (rid >= 1000) {
            TaskPrefs.remove(c, i.getStringExtra("key"));
            TaskPrefs.scheduleAll(c);
        }
    }

    public static void notifyNow(Context c, String title, String text) {
        createChannel(c);
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                c, 10, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CH)
                : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title == null ? "Study Tracker" : title)
                .setContentText(text == null ? "Time to study!" : text)
                .setAutoCancel(true)
                .setContentIntent(pi);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify((int) (System.currentTimeMillis() % 100000), b.build());
    }

    public static void schedule(Context c, int id, String hm, String title, String text) {
        try {
            int requestCode = 200 + id;
            Intent in = new Intent(c, ReminderReceiver.class)
                    .putExtra("id", id + 1)
                    .putExtra("title", title)
                    .putExtra("text", text);
            PendingIntent pi = PendingIntent.getBroadcast(
                    c, requestCode, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);

            if (hm == null || hm.length() < 4) {
                am.cancel(pi);
                return;
            }

            String[] p = hm.split(":");
            int h = Integer.parseInt(p[0]);
            int m = Integer.parseInt(p[1]);
            Calendar cal = Calendar.getInstance();
            cal.set(Calendar.HOUR_OF_DAY, h);
            cal.set(Calendar.MINUTE, m);
            cal.set(Calendar.SECOND, 0);
            cal.set(Calendar.MILLISECOND, 0);
            if (cal.before(Calendar.getInstance())) cal.add(Calendar.DATE, 1);

            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), pi);
            } else {
                am.setRepeating(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
            }
        } catch (Exception ignored) {
        }
    }

    public static void scheduleAt(Context c, String key, String iso, String title, String text) {
        try {
            if (key == null || iso == null || iso.length() < 16) return;
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.getDefault());
            f.setLenient(false);
            Date d = f.parse(iso);
            if (d == null || d.getTime() <= System.currentTimeMillis()) return;

            int rid = taskRequestCode(key);
            Intent in = new Intent(c, ReminderReceiver.class)
                    .putExtra("title", title)
                    .putExtra("text", text)
                    .putExtra("id", rid)
                    .putExtra("key", key);
            PendingIntent pi = PendingIntent.getBroadcast(
                    c, rid, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, d.getTime(), pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, d.getTime(), pi);
            }
            TaskPrefs.save(c, key, iso, title, text);
        } catch (Exception ignored) {
        }
    }

    public static void cancelTask(Context c, String key) {
        int rid = taskRequestCode(key);
        Intent in = new Intent(c, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(
                c, rid, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        am.cancel(pi);
        pi.cancel();
        TaskPrefs.remove(c, key);
    }

    private static int taskRequestCode(String key) {
        return 1000 + Math.abs((key == null ? "" : key).hashCode() % 8000);
    }

    public static void scheduleStudy(Context c, String key, String iso, String title, String text) {
        try {
            if (key == null || iso == null || iso.length() < 16) return;
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.getDefault());
            f.setLenient(false); Date d = f.parse(iso);
            if (d == null || d.getTime() <= System.currentTimeMillis()) return;
            int rid = 50000 + Math.abs((key).hashCode() % 9000);
            Intent in = new Intent(c, ReminderReceiver.class).putExtra("title", title).putExtra("text", text).putExtra("id", rid).putExtra("key", key);
            PendingIntent pi = PendingIntent.getBroadcast(c, rid, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
            if (Build.VERSION.SDK_INT >= 31 && am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, d.getTime(), pi);
            else if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, d.getTime(), pi);
            else am.set(AlarmManager.RTC_WAKEUP, d.getTime(), pi);
            StudyReminderPrefs.save(c,key,iso,title,text);
        } catch(Exception ignored) {}
    }

    public static void cancelStudy(Context c, String key) {
        int rid = 50000 + Math.abs((key == null ? "" : key).hashCode() % 9000);
        Intent in = new Intent(c, ReminderReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, rid, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE); am.cancel(pi); pi.cancel(); StudyReminderPrefs.remove(c,key);
    }
}

class StudyReminderPrefs {
    static final String K="study_reminders";
    static void save(Context c,String key,String iso,String title,String text){try{org.json.JSONArray a=new org.json.JSONArray(c.getSharedPreferences("study_reminders",0).getString(K,"[]"));org.json.JSONArray b=new org.json.JSONArray();for(int i=0;i<a.length();i++){org.json.JSONObject o=a.getJSONObject(i);if(!o.optString("key").equals(key))b.put(o);}org.json.JSONObject n=new org.json.JSONObject();n.put("key",key);n.put("iso",iso);n.put("title",title);n.put("text",text);b.put(n);c.getSharedPreferences("study_reminders",0).edit().putString(K,b.toString()).apply();}catch(Exception ignored){}}
    static void remove(Context c,String key){try{org.json.JSONArray a=new org.json.JSONArray(c.getSharedPreferences("study_reminders",0).getString(K,"[]"));org.json.JSONArray b=new org.json.JSONArray();for(int i=0;i<a.length();i++)if(!a.getJSONObject(i).optString("key").equals(key))b.put(a.getJSONObject(i));c.getSharedPreferences("study_reminders",0).edit().putString(K,b.toString()).apply();}catch(Exception ignored){}}
    static void scheduleAll(Context c){try{org.json.JSONArray a=new org.json.JSONArray(c.getSharedPreferences("study_reminders",0).getString(K,"[]"));for(int i=0;i<a.length();i++){org.json.JSONObject o=a.getJSONObject(i);ReminderReceiver.scheduleStudy(c,o.optString("key"),o.optString("iso"),o.optString("title"),o.optString("text"));}}catch(Exception ignored){}}
}

class Prefs {
    static void save(Context c, String a, String b, String g) {
        c.getSharedPreferences("reminders", 0).edit()
                .putString("morning", a)
                .putString("night", b)
                .putString("goal", g)
                .apply();
    }

    static void schedule(Context c) {
        android.content.SharedPreferences p = c.getSharedPreferences("reminders", 0);
        ReminderReceiver.schedule(c, 0,
                p.getString("morningEnabled", "false").equals("true") ? p.getString("morning", "07:00") : "",
                "Morning Study Reminder", "Time to start your study session 📚");
        ReminderReceiver.schedule(c, 1,
                p.getString("nightEnabled", "false").equals("true") ? p.getString("night", "21:00") : "",
                "Night Study Reminder", "Review your plan and finish your remaining study goal ⏰");
        ReminderReceiver.schedule(c, 2,
                p.getString("goalEnabled", "false").equals("true") ? p.getString("goal", "21:00") : "",
                "Daily Goal Check", "Check your Study Tracker daily goal and complete any remaining study time 🎯");
    }
}

class TaskPrefs {
    static final String K = "task_reminders";

    static void save(Context c, String key, String iso, String title, String text) {
        try {
            org.json.JSONArray a = new org.json.JSONArray(
                    c.getSharedPreferences("tasks", 0).getString(K, "[]"));
            org.json.JSONArray b = new org.json.JSONArray();
            for (int i = 0; i < a.length(); i++) {
                org.json.JSONObject o = a.getJSONObject(i);
                if (!o.optString("key").equals(key)) b.put(o);
            }
            org.json.JSONObject n = new org.json.JSONObject();
            n.put("key", key);
            n.put("iso", iso);
            n.put("title", title);
            n.put("text", text);
            b.put(n);
            c.getSharedPreferences("tasks", 0).edit().putString(K, b.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static void remove(Context c, String key) {
        try {
            org.json.JSONArray a = new org.json.JSONArray(
                    c.getSharedPreferences("tasks", 0).getString(K, "[]"));
            org.json.JSONArray b = new org.json.JSONArray();
            for (int i = 0; i < a.length(); i++) {
                if (!a.getJSONObject(i).optString("key").equals(key)) b.put(a.getJSONObject(i));
            }
            c.getSharedPreferences("tasks", 0).edit().putString(K, b.toString()).apply();
        } catch (Exception ignored) {
        }
    }

    static void scheduleAll(Context c) {
        try {
            org.json.JSONArray a = new org.json.JSONArray(
                    c.getSharedPreferences("tasks", 0).getString(K, "[]"));
            for (int i = 0; i < a.length(); i++) {
                org.json.JSONObject o = a.getJSONObject(i);
                ReminderReceiver.scheduleAt(c, o.optString("key"), o.optString("iso"),
                        o.optString("title"), o.optString("text"));
            }
        } catch (Exception ignored) {
        }
    }
}
